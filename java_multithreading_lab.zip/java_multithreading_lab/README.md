# Java Multithreading Lab

This project demonstrates three concurrent threads that print messages at different intervals.

## Files
- `ThreadClassDemo.java` — creates threads by extending `Thread`.
- `RunnableDemo.java` — creates threads by implementing `Runnable`.

## Requirements
- Java JDK installed

## Compile and run Method 1
```bash
javac ThreadClassDemo.java
java ThreadClassDemo
```

## Compile and run Method 2
```bash
javac RunnableDemo.java
java RunnableDemo
```

The programs run continuously until stopped manually (for example, with Ctrl+C in the terminal).
Output order can vary because the threads execute concurrently.
